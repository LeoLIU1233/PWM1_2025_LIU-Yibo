<?php
/**
 * Plugin Name: Kids Nutrition Fun - AI Chatbot
 * Description: COMP OpenAI-powered bilingual chatbot for Kids Nutrition Fun
 * Version: 5.0.0
 */
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_options_page('AI Chatbot Settings', 'AI Chatbot', 'manage_options', 'kids-chatbot', 'kids_chatbot_settings_page');
});

function kids_chatbot_settings_page() {
    if (isset($_POST['kids_chatbot_api_key'])) {
        update_option('kids_chatbot_api_key', sanitize_text_field($_POST['kids_chatbot_api_key']));
        echo '<div class="updated"><p>Settings saved!</p></div>';
    }
    $api_key = get_option('kids_chatbot_api_key', '');
    ?>
    <div class="wrap">
        <h1>AI Chatbot Settings (COMP OpenAI)</h1>
        <form method="post">
            <table class="form-table">
                <tr>
                    <th scope="row">COMP OpenAI Subscription Key</th>
                    <td>
                        <input type="password" name="kids_chatbot_api_key"
                               value="<?php echo esc_attr($api_key); ?>"
                               style="width:480px" placeholder="Paste your subscription key here..." />
                        <p class="description">
                            Endpoint: <code>https://comp.azure-api.net/azure</code> | Model: <code>gpt4o-mini</code>
                        </p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Settings'); ?>
        </form>
    </div>
    <?php
}

add_action('wp_ajax_kids_chatbot_message', 'kids_chatbot_handle_message');
add_action('wp_ajax_nopriv_kids_chatbot_message', 'kids_chatbot_handle_message');

function kids_chatbot_handle_message() {
    check_ajax_referer('kids_chatbot_nonce', 'nonce');
    $api_key = get_option('kids_chatbot_api_key', '');
    if (empty($api_key)) wp_send_json_error(['message' => 'API key not configured.']);

    $user_message = sanitize_text_field($_POST['message'] ?? '');
    $history      = isset($_POST['history']) ? $_POST['history'] : [];
    if (empty($user_message)) wp_send_json_error(['message' => 'Empty message.']);

    $system_prompt = "You are Nutri, a friendly bilingual (English & Chinese) nutrition assistant for Kids Nutrition Fun (https://kids-nutrition-fun.com/), helping parents raise healthy children aged 3-12.
- Answer questions about children's nutrition, recipes, food allergies, healthy eating habits
- Always reply in the SAME language the user writes in (Chinese or English)
- Follow WHO & CDC guidelines
- Keep answers practical and under 150 words
- Recommend website features: personalized recipes, fun games, progress reports, free signup at https://kids-nutrition-fun.com/login";

    $messages = [['role' => 'system', 'content' => $system_prompt]];
    if (is_array($history)) {
        foreach (array_slice($history, -6) as $h) {
            if (isset($h['role'], $h['content'])) {
                $messages[] = ['role' => sanitize_text_field($h['role']), 'content' => sanitize_text_field($h['content'])];
            }
        }
    }
    $messages[] = ['role' => 'user', 'content' => $user_message];

    $response = wp_remote_post('https://comp.azure-api.net/azure/openai/deployments/gpt4o-mini/chat/completions', [
        'timeout' => 30,
        'headers' => ['Api-key' => $api_key, 'Content-Type' => 'application/json'],
        'body'    => json_encode(['messages' => $messages, 'max_tokens' => 400, 'temperature' => 0.7]),
    ]);

    if (is_wp_error($response)) wp_send_json_error(['message' => 'Connection error: ' . $response->get_error_message()]);

    $http_code = wp_remote_retrieve_response_code($response);
    $body      = json_decode(wp_remote_retrieve_body($response), true);

    if ($http_code === 429) {
        $msg = isset($body['message']) ? $body['message'] : '';
        wp_send_json_error(['message' => strpos($msg, 'All tokens used') !== false ? 'API quota used up.' : 'Service busy, please retry.']);
    }
    if ($http_code === 500) wp_send_json_error(['message' => 'Invalid API key. Check Settings > AI Chatbot.']);

    $reply = $body['choices'][0]['message']['content'] ?? '';
    if (empty($reply)) wp_send_json_error(['message' => 'No response. Please try again.']);
    wp_send_json_success(['message' => $reply]);
}

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('kids-chatbot-style', plugin_dir_url(__FILE__) . 'chatbot.css', [], '5.0.0');
    wp_enqueue_script('kids-chatbot-script', plugin_dir_url(__FILE__) . 'chatbot.js', ['jquery'], '5.0.0', true);
    wp_localize_script('kids-chatbot-script', 'kidsChatbot', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('kids_chatbot_nonce'),
    ]);
});

add_action('wp_footer', function () { ?>
<div id="kids-chatbot-widget">
    <button id="kids-chatbot-toggle" aria-label="Open chat">
        <!-- Apple SVG drawn inline: red body + green leaf + stem + shine, no font needed -->
        <svg class="chat-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="34" height="34" aria-hidden="true">
            <!-- Apple body left half -->
            <path d="M32 18 C16 18 10 30 10 40 C10 52 18 58 26 58 C29 58 31 56 32 56 C33 56 35 58 38 58 C46 58 54 52 54 40 C54 30 48 18 32 18Z" fill="#e53935"/>
            <!-- Highlight shine -->
            <ellipse cx="22" cy="30" rx="5" ry="8" fill="#ef9a9a" opacity="0.45"/>
            <!-- Stem -->
            <path d="M32 18 Q34 10 40 11" stroke="#5D4037" stroke-width="2.5" fill="none" stroke-linecap="round"/>
            <!-- Leaf -->
            <path d="M34 14 Q42 8 44 16 Q38 18 34 14Z" fill="#43A047"/>
        </svg>
        <!-- Close X (shown when open) -->
        <svg class="close-icon" style="display:none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="white" stroke-width="2.8" stroke-linecap="round" aria-hidden="true">
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
        <span class="notif-badge">1</span>
    </button>

    <div id="kids-chatbot-window" style="display:none">
        <div id="kids-chatbot-header">
            <div class="header-info">
                <div class="avatar">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" width="26" height="26" aria-hidden="true">
                        <circle cx="14" cy="15" r="10" fill="#81C784"/>
                        <circle cx="26" cy="13" r="9" fill="#66BB6A"/>
                        <circle cx="20" cy="11" r="8" fill="#A5D6A7"/>
                        <rect x="18" y="23" width="4" height="11" rx="2" fill="#388E3C"/>
                    </svg>
                </div>
                <div>
                    <div class="bot-name">Nutri Assistant</div>
                    <div class="bot-status">&#9679; Online / &#22312;&#32447;</div>
                </div>
            </div>
            <button id="kids-chatbot-close">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="white" stroke-width="2.8" stroke-linecap="round" aria-hidden="true">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
            </button>
        </div>

        <div id="kids-chatbot-messages">
            <div class="message bot-message">
                <div class="message-bubble">
                    Hi! I'm Nutri, your kids' nutrition assistant!<br><br>
                    &#20320;&#22909;&#65281;&#25105;&#26159; Nutri&#65292;&#24744;&#30340;&#20799;&#31461;&#33829;&#20859;&#23567;&#21161;&#25163;&#65281;<br><br>
                    Ask me anything about healthy eating for your child!
                </div>
            </div>
        </div>

        <div id="kids-chatbot-input-area">
            <input type="text" id="kids-chatbot-input"
                   placeholder="Ask a question... / &#35831;&#36755;&#20837;&#38382;&#39064;..."
                   autocomplete="off" />
            <button id="kids-chatbot-send">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="22" y1="2" x2="11" y2="13"></line>
                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
            </button>
        </div>
        <div id="kids-chatbot-footer">Powered by Kids Nutrition Fun AI</div>
    </div>
</div>
<?php });
