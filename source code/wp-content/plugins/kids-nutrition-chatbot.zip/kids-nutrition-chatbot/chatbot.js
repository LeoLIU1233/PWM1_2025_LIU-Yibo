(function ($) {
    var toggle  = $('#kids-chatbot-toggle');
    var window_ = $('#kids-chatbot-window');
    var closeBtn= $('#kids-chatbot-close');
    var input   = $('#kids-chatbot-input');
    var sendBtn = $('#kids-chatbot-send');
    var msgArea = $('#kids-chatbot-messages');
    var history = [];
    var isOpen  = false;

    function toggleChat() {
        isOpen = !isOpen;
        if (isOpen) {
            window_.show();
            toggle.find('.chat-icon').hide();
            toggle.find('.close-icon').show();
            toggle.find('.notif-badge').hide();
            input.focus(); scrollBottom();
        } else {
            window_.hide();
            toggle.find('.chat-icon').show();
            toggle.find('.close-icon').hide();
        }
    }

    function scrollBottom() { msgArea.scrollTop(msgArea[0].scrollHeight); }

    function escapeHtml(t) {
        return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br>');
    }

    function addMessage(text, role) {
        var cls = role === 'user' ? 'user-message' : 'bot-message';
        msgArea.append('<div class="message '+cls+'"><div class="message-bubble">'+escapeHtml(text)+'</div></div>');
        scrollBottom();
    }

    function showTyping() {
        msgArea.append('<div class="message bot-message" id="typing-indicator"><div class="message-bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div></div>');
        scrollBottom();
    }

    function removeTyping() { $('#typing-indicator').remove(); }

    function sendMessage() {
        var text = input.val().trim();
        if (!text) return;
        addMessage(text, 'user');
        history.push({role:'user', content:text});
        input.val(''); sendBtn.prop('disabled', true); showTyping();

        $.post(kidsChatbot.ajaxUrl, {
            action:'kids_chatbot_message', nonce:kidsChatbot.nonce,
            message:text, history:history.slice(-6)
        })
        .done(function(res) {
            removeTyping();
            if (res.success) { addMessage(res.data.message, 'bot'); history.push({role:'assistant', content:res.data.message}); }
            else { addMessage(res.data.message || 'Something went wrong.', 'bot'); }
        })
        .fail(function() { removeTyping(); addMessage('Connection error. Please check your internet.', 'bot'); })
        .always(function() { sendBtn.prop('disabled', false); input.focus(); });
    }

    toggle.on('click', toggleChat);
    closeBtn.on('click', toggleChat);
    sendBtn.on('click', sendMessage);
    input.on('keydown', function(e) { if (e.key === 'Enter') sendMessage(); });
})(jQuery);
